#!/bin/bash


python3 ./code/assignment4.py "$1"                          
